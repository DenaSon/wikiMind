<?php

namespace Denason\Wikimind\Fluents;

use Denason\Wikimind\Interfaces\MindQueryInterface;
use Denason\Wikimind\Actions\ExecuteMindQueryAction;

/**
 * Class MindQuery
 *
 * Fluent builder for constructing and executing SPARQL queries on Wikidata.
 *
 * @package Denason\Wikimind\Fluents
 */
class MindQuery implements MindQueryInterface
{
    protected array $select = [];
    protected array $wheres = [];
    protected array $optionals = [];
    protected array $filters = [];
    protected string $lang = 'en';
    protected int $limit = 10;
    protected ?string $orderBy = null;
    protected string $orderDir = 'ASC';

    public function select(array $vars): self
    {
        $this->select = $vars;
        return $this;
    }

    public function where(string $subject, string $predicate, string $object): self
    {
        $this->wheres[] = [$subject, $predicate, $object];
        return $this;
    }

    public function optional(string $subject, string $predicate, string $object): self
    {
        $this->optionals[] = [$subject, $predicate, $object];
        return $this;
    }

    public function filter(string $expression): self
    {
        $this->filters[] = $expression;
        return $this;
    }

    public function lang(string $lang): self
    {
        $this->lang = $lang;
        return $this;
    }

    public function limit(int $count): self
    {
        $this->limit = $count;
        return $this;
    }

    public function orderBy(string $var, string $direction = 'asc'): self
    {
        $this->orderBy = $var;
        $this->orderDir = strtoupper($direction) === 'DESC' ? 'DESC' : 'ASC';
        return $this;
    }




    public function get(): array
    {
        return (new ExecuteMindQueryAction())->execute(
            $this->select,
            $this->wheres,
            $this->optionals,
            $this->filters,
            $this->lang,
            $this->limit,
            $this->orderBy,
            $this->orderDir
        );
    }
}
